import relation.Tableau;

public class Main {
    
    public static void main(String[] args) throws Exception {
        Manager manager = new Manager();
    
        manager.loadTablesFromTextFile("tables.txt");
        System.out.println(manager.executeQuery("DESC Employees"));
        Tableau tab = (Tableau) manager.executeQuery("SELECT * FROM Employees");
        tab.afficherTableau();
    }
    

}