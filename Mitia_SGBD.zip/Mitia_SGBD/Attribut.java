package relation;

import java.util.Objects;
import java.io.Serializable;

public class Attribut implements Serializable
{
    private String nom;
    private Domaine domaine;

    public Attribut(String nom, Domaine domaine) 
    {
        this.nom = nom;
        this.domaine = domaine;
    }


    public String getNom() {
        return nom;
    }

    public Domaine getDomaine() {
        return domaine;
    }

    @Override
    public boolean equals(Object obj) 
    {
        if (this == obj) return true; 
        if (obj == null || getClass() != obj.getClass()) return false;
        Attribut attribut = (Attribut) obj;
        return nom.equals(attribut.nom) && domaine.equals(attribut.domaine);
    }

    @Override
    public int hashCode() 
    {
        return Objects.hash(nom, domaine);
    }

    
    @Override
    public String toString() {
        return "Attribut{"
                + "nom='" + nom + '\''
                + ", domaine=" + domaine
                + '}';
    }
}
