package operation;

import java.util.ArrayList;
import java.util.HashSet;
import relation.*;

public class Operation {

    public Operation()
    {}

    public Tableau Intersection(Tableau tab1, Tableau tab2)
    {
        ArrayList<Nuplet> NewLignes = new ArrayList<>();
        for (Nuplet elem : tab1.getLignes()) 
        {
            if (tab2.getLignes().contains(elem)) {
                NewLignes.add(elem);
            }
        }
        tab1.setLignes(NewLignes);
        return tab1;
    }

    
    public Tableau Difference(Tableau tab1, Tableau tab2)//A - B
    {
        ArrayList<Nuplet> NewLignes = new ArrayList<>();
        for (Nuplet elem : tab1.getLignes()) 
        {
            if (!tab2.getLignes().contains(elem)) {
                NewLignes.add(elem);
            }
        }
        tab1.setLignes(NewLignes);
        return tab1;
    }

    //UNION
    public boolean VerifieCompatibility(Tableau tab1, Tableau tab2) {
        if (tab1.getAttributs().size() != tab2.getAttributs().size()) {
            System.out.println("Erreur, Tableaux Incompatibles (nombre d'attributs différent).");
            return false;
        }
    
        for (int i = 0; i < tab1.getAttributs().size(); i++) {
            Attribut attributTab1 = tab1.getAttributs().get(i);
            Attribut attributTab2 = tab2.getAttributs().get(i);
    
            // Vérification des domaines pour chaque attribut
            for (Nuplet ligne : tab2.getLignes()) {
                Object valeur = ligne.getDonnees().get(i);
                if (!attributTab1.getDomaine().isCompatible(valeur.getClass())) {
                    // Ajout dynamique du type au domaine si absent
                    System.out.println("Ajout du type " + valeur.getClass().getSimpleName() 
                        + " au domaine de l'attribut '" + attributTab1.getNom() + "'.");
                    attributTab1.getDomaine().ajouterType(valeur.getClass());
                }
            }
        }
    
        return true; // Si aucun problème de compatibilité n'est trouvé
    }
    
    public Tableau Union(Tableau tab1, Tableau tab2) {
        if (VerifieCompatibility(tab1, tab2)) {
            for (Nuplet nuplet : tab2.getLignes()) {
                tab1.getLignes().add(nuplet);
            }
            tab1.setLignes(VerificationDoublon(tab1.getLignes()));
        } else {
            System.out.println("Tables are not compatible for union.");
        }
        return tab1;
    }
    
    
    //SELECTION
    public Tableau selection(String attributRecherche, String operateur, Object valeurRecherche, Tableau tab) {
    ArrayList<Nuplet> lignesVaovao = new ArrayList<>();

    // Trouver l'index de l'attribut à partir du nom
    int indexAttribut = -1;
    for (int i = 0; i < tab.getAttributs().size(); i++) {
        if (tab.getAttributs().get(i).getNom().equals(attributRecherche)) {
            indexAttribut = i;
            break;
        }
    }

    if (indexAttribut == -1) {
        throw new IllegalArgumentException("Attribut non trouvé : " + attributRecherche);
    }

    // Parcourir chaque ligne pour tester la condition
    for (Nuplet nuplet : tab.getLignes()) {
        Object[] ligneData = nuplet.getDonnees().toArray();
        Object valeurColonne = ligneData[indexAttribut];

        boolean conditionRemplie = false;

        try {
            switch (operateur) {
                case "=":
                    conditionRemplie = valeurColonne.equals(valeurRecherche);
                    break;
                case "<":
                    if (valeurColonne instanceof Comparable && valeurRecherche instanceof Comparable) {
                        conditionRemplie = compare(valeurColonne, valeurRecherche) < 0;
                    }
                    break;
                case ">":
                    if (valeurColonne instanceof Comparable && valeurRecherche instanceof Comparable) {
                        conditionRemplie = compare(valeurColonne, valeurRecherche) > 0;
                    }
                    break;
                case "<>":
                    conditionRemplie = !valeurColonne.equals(valeurRecherche);
                    break;
                case "LIKE":
                    if (valeurColonne instanceof String && valeurRecherche instanceof String) {
                        String valeurString = (String) valeurColonne;
                        String motif = (String) valeurRecherche;
                        conditionRemplie = valeurString.matches(motif.replace("%", ".*"));
                    }
                    break;
                    case "<=":
                    if (valeurColonne instanceof Comparable && valeurRecherche instanceof Comparable) {
                        conditionRemplie = compare(valeurColonne, valeurRecherche) <= 0;
                    }
                    break;
                case ">=":
                    if (valeurColonne instanceof Comparable && valeurRecherche instanceof Comparable) {
                        conditionRemplie = compare(valeurColonne, valeurRecherche) >= 0;
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Opérateur non supporté : " + operateur);
            }
        } catch (ClassCastException e) {
            throw new IllegalArgumentException("Type mismatch: " + valeurColonne.getClass().getName() +
                                               " and " + valeurRecherche.getClass().getName());
        }

        if (conditionRemplie) {
            lignesVaovao.add(nuplet);
        }
    }

    // Retourner un nouveau tableau avec les lignes sélectionnées
    return new Tableau(tab.getAttributs(), lignesVaovao, tab.getAttributs().size());
}

@SuppressWarnings("unchecked")
private <T> int compare(T o1, T o2) {
    if (o1 instanceof Comparable && o2 instanceof Comparable) {
        return ((Comparable<T>) o1).compareTo(o2);
    }
    throw new IllegalArgumentException("Les objets ne sont pas comparables.");
}

    
    //CARTESIEN
    public Tableau ProduitCartesien(Tableau tab1, Tableau tab2) 
    {
        int urite = tab2.getAttributs().size() + tab1.getAttributs().size();
        ArrayList<Attribut> NewAttribut = new ArrayList<>();
        ArrayList<Nuplet> List_Donnee = new ArrayList<>();
        for (Attribut att : tab1.getAttributs()) 
        {
            NewAttribut.add(att);
        }
        // Ajout des attributs de tab2
        for (Attribut att1 : tab2.getAttributs()) 
        {
            NewAttribut.add(att1);
        }
        for (Nuplet nuplet1 : tab1.getLignes()) 
        {
            for (Nuplet nuplet2 : tab2.getLignes()) 
            {
                ArrayList<Object> NewDonnee = new ArrayList<>();
                NewDonnee.addAll(nuplet1.getDonnees());
                NewDonnee.addAll(nuplet2.getDonnees());
                List_Donnee.add(new Nuplet(NewDonnee));
            }
        }
        return new Tableau(NewAttribut, List_Donnee, urite);
    }

    //PROJECTION FUNCTIONS
    public ArrayList<Nuplet> VerificationDoublon(ArrayList<Nuplet> lignes) {
        lignes = new ArrayList<>(new HashSet<>(lignes));
        return lignes;
    }

    public Tableau Projection(Tableau tab, ArrayList<Attribut> colonnesIlaina) {
        // Trouver les indices des colonnes sélectionnées dans le tableau initial
        ArrayList<Integer> indicesColonnes = new ArrayList<>();
        ArrayList<Attribut> NewAttributs = new ArrayList<>();
        
        for (Attribut attribut : colonnesIlaina) {
            boolean attributTrouve = false;
            for (int i = 0; i < tab.getAttributs().size(); i++) {
                if (tab.getAttributs().get(i).equals(attribut)) {
                    indicesColonnes.add(i);
                    NewAttributs.add(attribut); // Ajouter à la liste des nouveaux attributs
                    attributTrouve = true;
                    break;
                }
            }
            if (!attributTrouve) {
                throw new IllegalArgumentException("Attribut non trouvé : " + attribut.getNom());
            }
        }
    
        // Construire les nouveaux nuplets avec uniquement les colonnes nécessaires
        ArrayList<Nuplet> nouvellesLignes = new ArrayList<>();
        for (Nuplet ligne : tab.getLignes()) {
            ArrayList<Object> nouvellesDonnees = new ArrayList<>();
            for (int index : indicesColonnes) {
                Object valeur = ligne.getDonnees().get(index);
                nouvellesDonnees.add(valeur);
            }
            nouvellesLignes.add(new Nuplet(nouvellesDonnees));
        }
    
        // Retourner le nouveau tableau projeté
        return new Tableau(NewAttributs, nouvellesLignes, NewAttributs.size());
    }
    
    public Nuplet ProjectionUplet(int urite, Nuplet donnee) {
        ArrayList<Object> nouvelleDonnees = new ArrayList<>();
        int count = 0;

        for (Object elem : donnee.getDonnees()) {
            if (count < urite) {
                nouvelleDonnees.add(elem);
                count++;
            } else {
                break;
            }
        }
        return new Nuplet(nouvelleDonnees);
    }

}
