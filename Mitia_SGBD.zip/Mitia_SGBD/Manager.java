import java.io.*;
import java.util.*;
import java.util.regex.*;
import operation.Operation;
import relation.Attribut;
import relation.Domaine;
import relation.Nuplet;
import relation.Tableau;

public class Manager {
    private Map<String, Tableau> tables;
    public Operation operation = new Operation();

    public Manager() {
        tables = new HashMap<>();
    }



    //Enregistrement

    public void loadTablesFromTextFile(String fileName) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            Tableau currentTable = null;
            String currentTableName = null;
    
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Table:")) {
                    currentTableName = line.substring(6).trim();
                    currentTable = new Tableau(new ArrayList<>(), new ArrayList<>(), 0);
                    tables.put(currentTableName, currentTable);
                } else if (line.startsWith("Columns:")) {
                    String[] columns = line.substring(8).trim().split("\\s+");
                    for (String col : columns) {
                        String[] parts = col.split("\\(");
                        String colName = parts[0];
                        String colType = parts[1].replace(")", "");
    
                        Domaine domaine;
                        switch (colType) {
                            case "String":
                                domaine = new Domaine(List.of(String.class));
                                break;
                            case "Integer":
                                domaine = new Domaine(List.of(Integer.class));
                                break;
                            case "Boolean":
                                domaine = new Domaine(List.of(Boolean.class));
                                break;
                            default:
                                throw new IOException("Unsupported type: " + colType);
                        }
                        currentTable.getAttributs().add(new Attribut(colName, domaine));
                    }
                } else if (line.startsWith("Rows:")) {
                    // Les lignes commencent juste après cette section
                    while ((line = reader.readLine()) != null && !line.trim().isEmpty()) {
                        String[] values = line.split("\t");
                        ArrayList<Object> rowValues = new ArrayList<>();
                        for (int i = 0; i < values.length; i++) {
                            Attribut attr = currentTable.getAttributs().get(i);
                            Object convertedValue = convertValueToType(values[i], attr.getDomaine().getType());
                            rowValues.add(convertedValue);
                        }
                        currentTable.getLignes().add(new Nuplet(rowValues));
                    }
                }
            }
            //System.out.println("Recuperation okey");
        } catch (Exception e) {
            throw new IOException("Error while loading tables: " + e.getMessage());
        }
    }
    
    public void saveTablesToTextFile(String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Map.Entry<String, Tableau> entry : tables.entrySet()) {
                String tableName = entry.getKey();
                Tableau table = entry.getValue();
    
                // Écrire le nom de la table
                writer.write("Table: " + tableName);
                writer.newLine();
    
                // Écrire les colonnes
                writer.write("Columns:");
                for (Attribut col : table.getAttributs()) {
                    writer.write(" " + col.getNom() + "(" + col.getDomaine().getType().getSimpleName() + ")");
                }
                writer.newLine();
    
                // Écrire les lignes
                writer.write("Rows:");
                writer.newLine();
                for (Nuplet row : table.getLignes()) {
                    for (Object value : row.getDonnees()) {
                        writer.write(value.toString() + "\t");
                    }
                    writer.newLine();
                }
                writer.newLine();
            }
            System.out.println("Tables saved to " + fileName);
        }
    }
    
    public String showTables() throws Exception{
        if (tables.isEmpty()) {
            throw new Exception("No tables available");
        }
    
        StringBuilder result = new StringBuilder("Tables:\n");
        for (String tableName : tables.keySet()) {
            result.append("- ").append(tableName).append("\n");
        }
        return result.toString();
    }


    public String describeTable(String query) throws Exception {
        query = query.trim();
        
        if (query.startsWith("DESC") || query.startsWith("DESCRIBE")) {
            // Extraire le nom de la table après "DESC" ou "DESCRIBE"
            String tableName = query.substring(query.indexOf(" ") + 1).trim();
    
            // Vérifier si la table existe dans la map
            if (!tables.containsKey(tableName)) {
                throw new Exception("Table '" + tableName + "' does not exist.");
            }
    
            // Récupérer la table et afficher la description
            Tableau table = tables.get(tableName);
            StringBuilder result = new StringBuilder("Description of table: " + tableName + "\n");
            result.append("Column Name\t \tType\n");
    
            // Afficher les colonnes de la table
            for (Attribut column : table.getAttributs()) {
                result.append(column.getNom()).append("\t\t").append(column.getDomaine()).append("\n");
            }
    
            return result.toString();
        } else {
            throw new IllegalArgumentException("Invalid DESCRIBE query. Expected syntax: DESCRIBE tableName");
        }
    }
    
    
    public Object executeQuery(String query) throws Exception {
        query = query.trim(); // Supprimer les espaces inutiles au début et à la fin
        
        if (query.matches("(?i)^SELECT .*")) {
            return select(query); // Appeler la méthode select pour les requêtes SELECT
        } else if (query.matches("(?i)^DELETE FROM .*")) {
            deleteFrom(query); // Appeler la méthode delete pour les requêtes DELETE
            return null; 
        } else if (query.matches("(?i)^INSERT INTO .*")) {
            insertInto(query); // Appeler la méthode insert pour les requêtes INSERT
            return null;
        } else if (query.matches("(?i)^CREATE TABLE .*")) {
            return createTable(query); // Appeler la méthode createTable pour les requêtes CREATE TABLE
        } else if (query.matches("(?i)^SHOW TABLES$")) {
            return showTables(); // Appeler la méthode showTables pour la requête SHOW TABLES
        } else if (query.matches("(?i)^DESC .*")) {
            return describeTable(query); // Appeler la méthode describeTable pour les requêtes DESC
        } else {
            throw new Exception("Unsupported query type: " + query); // Gérer les requêtes non supportées
        }
    }
    
    
    public void deleteFrom(String query) throws Exception {
        Pattern pattern = Pattern.compile("DELETE FROM (\\w+)( WHERE (.+))?", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(query);
    
        if (!matcher.find()) {
            throw new Exception("Invalid DELETE syntax");
        }
    
        String tableName = matcher.group(1).trim();
        String whereClause = matcher.group(3); // Clause WHERE (peut être null)
    
        Tableau table = tables.get(tableName);
        if (table == null) {
            throw new Exception("Table " + tableName + " does not exist.");
        }
    
        if (whereClause == null) {
            // Si aucune clause WHERE, supprimer toutes les données
            table.getLignes().clear();
            System.out.println("All rows deleted from table " + tableName);
        } else {
            Tableau filteredTable = select("SELECT * FROM " + tableName + " WHERE " + whereClause);
    
            // Supprimer ces lignes du tableau initial
            List<Nuplet> toRemove = filteredTable.getLignes();
            table.getLignes().removeIf(toRemove::contains);
            System.out.println(toRemove.size() + " rows deleted from table " + tableName);
        }
    }
    
    private Object convertValueToType(String value, Class<?> expectedType) throws Exception {
        if (expectedType == String.class) {
            return value; // Les chaînes try miova
        } else if (expectedType == Integer.class) {
            return Integer.parseInt(value); 
        } else if (expectedType == Double.class) {
            return Double.parseDouble(value); 
        } else if (expectedType == Boolean.class) {
            return Boolean.parseBoolean(value); 
        } else {
            throw new Exception("Unsupported type: " + expectedType);
        }
    }
    
    //function
    public Tableau select(String query) throws Exception {
        Pattern pattern = Pattern.compile("SELECT (.+) FROM (\\w+)( WHERE (.+))?", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(query);
    
        if (!matcher.find()) {
            throw new Exception("Invalid SELECT syntax");
        }
    
        String selectPart = matcher.group(1).trim();
        String tableName = matcher.group(2).trim();
        String whereClause = matcher.group(4); // Clause WHERE
        System.out.println("WHERE Clause: " + whereClause);
    
        // Récupération de la table source
        Tableau table = tables.get(tableName);
        if (table == null) {
            throw new Exception("Table " + tableName + " does not exist.");
        }
    
        Tableau filteredTable = table;
    
        // Gestion de la clause WHERE
        if (whereClause != null) {
            // Découper les conditions avec leurs séparateurs
            Pattern conditionPattern = Pattern.compile("\\s+(AND|OR)\\s+", Pattern.CASE_INSENSITIVE);
            String[] conditions = conditionPattern.split(whereClause);
            Matcher conditionMatcher = conditionPattern.matcher(whereClause);
    
            ArrayList<Tableau> conditionResults = new ArrayList<>();
            ArrayList<String> operators = new ArrayList<>();
    
            // Analyse des conditions et des opérateurs
            while (conditionMatcher.find()) {
                operators.add(conditionMatcher.group(1).toUpperCase()); // Récupérer les séparateurs (AND/OR)
            }
    
            for (String condition : conditions) {
                // Analyse de chaque condition
                Pattern wherePattern = Pattern.compile("(\\w+)\\s*(=|<>|<=|>=|<|>|LIKE)\\s*'?([^']+)'?", Pattern.CASE_INSENSITIVE);
                Matcher whereMatcher = wherePattern.matcher(condition.trim());
    
                if (!whereMatcher.find()) {
                    throw new Exception("Invalid WHERE clause syntax: " + condition);
                }
    
                String attributRecherche = whereMatcher.group(1).trim();
                String operateur = whereMatcher.group(2).trim();
                String valeurRecherche = whereMatcher.group(3).trim();
    
                System.out.println("Attribute: " + attributRecherche);
                System.out.println("Operator: " + operateur);
                System.out.println("Value: " + valeurRecherche);
    
                // Vérification de l'attribut dans la table
                Attribut attribut = null;
                for (Attribut attr : table.getAttributs()) {
                    if (attr.getNom().equalsIgnoreCase(attributRecherche)) {
                        attribut = attr;
                        break;
                    }
                }
    
                if (attribut == null) {
                    throw new Exception("Column " + attributRecherche + " not found in table " + tableName);
                }
    
                // Conversion de la valeur recherchée au bon type
                Object valeurConvertie = convertValueToType(valeurRecherche, attribut.getDomaine().getType());
    
                // Appliquer la sélection pour cette condition
                Tableau conditionTable = operation.selection(attributRecherche, operateur, valeurConvertie, table);
                conditionResults.add(conditionTable);
            }
    
            // Combinaison des résultats selon les opérateurs
            filteredTable = conditionResults.get(0); // Premier tableau
            for (int i = 0; i < operators.size(); i++) {
                String operator = operators.get(i);
                Tableau nextTable = conditionResults.get(i + 1); // Tableau suivant
    
                if (operator.equals("AND")) {
                    filteredTable = operation.Intersection(filteredTable, nextTable);
                } else if (operator.equals("OR")) {
                    filteredTable = operation.Union(filteredTable, nextTable);
                }
            }
        }
    
        // Gestion des colonnes à sélectionner
        if (selectPart.equals("*")) {
            return filteredTable; // Retourner toutes les colonnes
        } else {
            String[] columnNames = selectPart.split(",");
            ArrayList<Attribut> requiredAttributes = new ArrayList<>();
    
            for (String columnName : columnNames) {
                boolean found = false;
                for (Attribut attr : filteredTable.getAttributs()) {
                    if (attr.getNom().equalsIgnoreCase(columnName.trim())) {
                        requiredAttributes.add(attr);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    throw new Exception("Column " + columnName.trim() + " not found in table " + tableName);
                }
            }
    
            // Appliquer la projection pour sélectionner les colonnes demandées
            return operation.Projection(filteredTable, requiredAttributes);
        }
    }
    
    // Créer une table
    public Tableau createTable(String query) throws Exception {
        // Format attendu : CREATE TABLE TableName (id INT, Nom CHAR)
        Pattern pattern = Pattern.compile("CREATE TABLE (\\w+) \\((.+)\\)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(query);

        if (matcher.find()) {
            String tableName = matcher.group(1);
            String attributesPart = matcher.group(2);

            // Vérification si la table existe déjà
            if (tables.containsKey(tableName)) {
                throw new Exception("Table " + tableName + " already exists.");
            }

            String[] attributesArray = attributesPart.split(",");
            ArrayList<Attribut> colonnes = new ArrayList<>();

            for (String attributeDef : attributesArray) {
                String[] parts = attributeDef.trim().split(" ");
                if (parts.length != 2) {
                    throw new Exception("Invalid attribute definition: " + attributeDef);
                }
                String attributeName = parts[0];
                String attributeType = parts[1].toUpperCase();

                Domaine domaine;
                switch (attributeType) {
                    case "CHAR":
                        domaine = new Domaine(List.of(String.class));
                        break;
                    case "INT":
                        domaine = new Domaine(List.of(Integer.class));
                        break;
                    case "BOOLEAN":
                        domaine = new Domaine(List.of(Boolean.class));
                        break;
                    case "MIXTE":
                        domaine = new Domaine(List.of(String.class, Integer.class));
                        break;
                    default:
                        throw new Exception("Unsupported attribute type: " + attributeType);
                }

                colonnes.add(new Attribut(attributeName, domaine));
            }

            // Créer une nouvelle table vide
            Tableau table = new Tableau(colonnes, new ArrayList<>(), colonnes.size());
            tables.put(tableName, table);
            System.out.println("Table created: " + tableName);
            return table;
        } else {
            throw new Exception("Invalid CREATE TABLE syntax");
        }
    }

    // Fonction pour insérer des données dans une table
    public void insertInto(String query) throws Exception {
        Pattern pattern = Pattern.compile("INSERT INTO (\\w+) VALUES \\((.+)\\)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(query);

        if (matcher.find()) {
            String tableName = matcher.group(1);
            String valuesPart = matcher.group(2);

            Tableau table = tables.get(tableName);
            if (table == null) {
                throw new Exception("Table " + tableName + " does not exist.");
            }

            String[] valuesArray = valuesPart.split(",");
            ArrayList<Object> values = new ArrayList<>();
            for (String value : valuesArray) {
                value = value.trim();
                if (value.startsWith("'") && value.endsWith("'")) {
                    values.add(value.substring(1, value.length() - 1));
                } else if (value.matches("\\d+")) {
                    values.add(Integer.parseInt(value));
                } else if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
                    values.add(Boolean.parseBoolean(value));
                } else {
                    throw new Exception("Invalid value format: " + value);
                }
            }

            ArrayList<Attribut> colonnes = table.getAttributs();
            if (values.size() != colonnes.size()) {
                throw new Exception("Column count mismatch.");
            }

            for (int i = 0; i < values.size(); i++) {
                if (!colonnes.get(i).getDomaine().isCompatible(values.get(i).getClass())) {
                    throw new Exception("Type mismatch for column: " + colonnes.get(i).getNom());
                }
            }

            table.getLignes().add(new Nuplet(values));
            System.out.println("Data inserted into table " + tableName);
        } else {
            throw new Exception("Invalid INSERT INTO syntax");
        }
    }

    

}
