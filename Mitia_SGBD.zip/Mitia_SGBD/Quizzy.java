package aff;

import java.util.ArrayList;
import relation.*;

public class Quizzy {

    public static void main(String[] args) {

        // Domaine qui accepte des types comme Class<?> (ex: String.class, Integer.class)
        ArrayList<Class<?>> typesString = new ArrayList<>();
        typesString.add(String.class);
        Domaine domaineString = new Domaine(typesString);

        ArrayList<Class<?>> typesInteger = new ArrayList<>();
        typesInteger.add(Integer.class);
        Domaine domaineInteger = new Domaine(typesInteger);

        ArrayList<Class<?>> typesBoolean = new ArrayList<>();
        typesBoolean.add(Boolean.class);
        Domaine domaineBoolean = new Domaine(typesBoolean);

        // Domaine mixte qui accepte String et Integer
        ArrayList<Class<?>> typesMixte = new ArrayList<>();
        typesMixte.add(String.class);
        typesMixte.add(Integer.class);
        Domaine domaineMixte = new Domaine(typesMixte);


        //tab utilisateur 
        ArrayList<Attribut> colonnesUtilisateur = new ArrayList<>();
        colonnesUtilisateur.add(new Attribut("Nom", domaineString));   
        colonnesUtilisateur.add(new Attribut("Scores", domaineInteger));      

        ArrayList<Nuplet> ligneUtilisateur = new ArrayList<>();

        ArrayList<Object> u1 = new ArrayList<>();
        u1.add("Alice Manobal");
        u1.add(0); 
        ligneUtilisateur.add(new Nuplet(u1));

        Tableau tabUtilisateur = new Tableau(colonnesUtilisateur, ligneUtilisateur, colonnesUtilisateur.size());
        System.out.println("Tableau des questions de culture générale :");
        tabUtilisateur.afficherTableau();
        System.out.println();


        // Définir les colonnes pour le tableau
        ArrayList<Attribut> colonnesQuestions = new ArrayList<>();
        colonnesQuestions.add(new Attribut("Question", domaineString));      
        colonnesQuestions.add(new Attribut("AnswerOption", domaineString)); // Options disponibles (A, B, C, D)
        colonnesQuestions.add(new Attribut("Option", domaineInteger));       // ID de l'option (1)
        colonnesQuestions.add(new Attribut("Answer", domaineMixte));         // Réponse correcte

// Questions de culture générale pour l'option 1
ArrayList<Nuplet> generalKnowledgeQuestions = new ArrayList<>();

// Question 1
ArrayList<Object> q1 = new ArrayList<>();
q1.add("What is the capital of the Democratic Republic of Congo?");
q1.add("A) Kinshasa B) Kigali C) Nairobi D) Accra");
q1.add(1); // Option ID
q1.add("A");
generalKnowledgeQuestions.add(new Nuplet(q1));

// Question 2
ArrayList<Object> q2 = new ArrayList<>();
q2.add("Who painted the ceiling of the Sistine Chapel?");
q2.add("A) Leonardo da Vinci B) Michelangelo C) Raphael D) Donatello");
q2.add(1); // Option ID
q2.add("B");
generalKnowledgeQuestions.add(new Nuplet(q2));

// Question 3
ArrayList<Object> q3 = new ArrayList<>();
q3.add("What is the largest desert in the world?");
q3.add("A) Sahara B) Gobi C) Antarctic D) Kalahari");
q3.add(1); // Option ID
q3.add("C");
generalKnowledgeQuestions.add(new Nuplet(q3));

// Question 4
ArrayList<Object> q4 = new ArrayList<>();
q4.add("What is the currency of Japan?");
q4.add("A) Won B) Yen C) Yuan D) Dollar");
q4.add(1); // Option ID
q4.add("B");
generalKnowledgeQuestions.add(new Nuplet(q4));

// Question 5
ArrayList<Object> q5 = new ArrayList<>();
q5.add("Which element has the chemical symbol 'Au'?");
q5.add("A) Silver B) Gold C) Mercury D) Iron");
q5.add(1); // Option ID
q5.add("B");
generalKnowledgeQuestions.add(new Nuplet(q5));

        // Création du tableau des questions
        Tableau tabQuestions = new Tableau(colonnesQuestions, generalKnowledgeQuestions, colonnesQuestions.size());
        System.out.println("Tableau des questions de culture générale :");
        tabQuestions.afficherTableau();

    }
}
