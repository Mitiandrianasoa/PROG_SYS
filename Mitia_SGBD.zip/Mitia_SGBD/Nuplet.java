package relation;

import java.io.Serializable;
import java.util.ArrayList;

public class Nuplet implements Serializable{

    private ArrayList<Object> donnees = new ArrayList<>();
    
    public Nuplet(ArrayList<Object> donnees) 
    {
        this.donnees = donnees;
    }

    public ArrayList<Object> getDonnees() {
        return donnees;
    }

    @Override
    public int hashCode() {
        return donnees == null ? 0 : donnees.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(o instanceof Nuplet a)) {
            return false;
        }
        return donnees.equals(a.donnees);
    }

    @Override
    public String toString() {
        return this.donnees.toString();
    }

   
    
}
