package relation;

import java.util.ArrayList;
import java.io.Serializable;

public class Tableau implements Serializable{
    private ArrayList<Attribut> colonnes;
    private ArrayList<Nuplet> lignes;
    private int urite; // isana attributs


    public Tableau(ArrayList<Attribut> colonnes, ArrayList<Nuplet> lignes, int urite) {
        if (colonnes.size() != urite) {
            System.out.println("Erreur, Nombre de colonnes differents definis");
            return; 
        }

        for (Nuplet elem : lignes) {
            if (urite != elem.getDonnees().size()) {
                System.out.println("Erreur, Nombre de colonnes et ligne ne correspondent pas");
                return; 
            }
        }

        if (verifierTypes(colonnes, lignes)) 
        {
            this.colonnes = colonnes;
            this.lignes = lignes;
            this.urite = urite;
        } else {
            System.out.println("Erreur de type dans les lignes.");
        }
    }

    
    public void effacerTableau() 
    {
        if (colonnes != null) {
            colonnes.clear();
        }
        if (lignes != null) {
            lignes.clear();
        }
        System.out.println("Le tableau a été effacé.");
    }
    



    public ArrayList<Attribut> getAttributs() 
    {
        return colonnes;
    }

    public ArrayList<Nuplet> getLignes() {
        return lignes;
    }

    public void setLignes(ArrayList<Nuplet> lignes) {
        this.lignes = lignes;
    }

    public void afficherTableau() {
        if (colonnes == null || lignes == null) {
            System.out.println("Aucune donnée à afficher.");
            return;
        }

        for (Attribut colonne : colonnes) {
            System.out.print(colonne.getNom() + "\t");
        }
        System.out.println();

        for (Nuplet nuplet : lignes) {
            ArrayList<Object> donnees = nuplet.getDonnees();
            for (Object donnee : donnees) {
                System.out.print(donnee + "\t");
            }
            System.out.println();
        }
    }

    public String StringTableau() {
        StringBuilder sb = new StringBuilder();  
        
        if (colonnes == null || lignes == null) {
            sb.append("Aucune donnée à afficher.\n");
            return sb.toString();  // Retourner le message d'erreur sous forme de chaîne
        }
    
        // Ajouter les noms des colonnes
        for (Attribut colonne : colonnes) {
            sb.append(colonne.getNom()).append("\t");
        }
        sb.append("\n");  // Nouvelle ligne après les noms des colonnes
    
        // Ajouter les données de chaque ligne
        for (Nuplet nuplet : lignes) {
            ArrayList<Object> donnees = nuplet.getDonnees();
            for (Object donnee : donnees) {
                sb.append(donnee).append("\t");
            }
            sb.append("\n");  // Nouvelle ligne après chaque enregistrement
        }
    
        return sb.toString();  // Retourner le tableau sous forme de chaîne de caractères
    }
    

    public static boolean verifierTypes(ArrayList<Attribut> colonnes, ArrayList<Nuplet> lignes) {
        for (Nuplet nuplet : lignes) {
            ArrayList<Object> donnees = nuplet.getDonnees();
    
            // Vérifiez si le nombre de données correspond au nombre de colonnes
            if (donnees.size() != colonnes.size()) {
                System.out.println("Erreur : le nombre de données dans le nuplet ne correspond pas au nombre de colonnes.");
                return false;
            }
    
            // Parcourez chaque donnée pour vérifier la compatibilité avec le domaine de la colonne
            for (int i = 0; i < colonnes.size(); i++) {
                Attribut colonne = colonnes.get(i);
                Object donnee = donnees.get(i);
    
                Domaine domaine = colonne.getDomaine();
                if (!domaine.isCompatible(donnee.getClass())) {
                    System.out.println("Type incompatible à l'indice " + i +
                            ": Attendu un des types " + domaine +
                            " mais trouvé " + donnee.getClass().getSimpleName());
                    return false;
                }
            }
        }
        return true;
    }
    
    
}
