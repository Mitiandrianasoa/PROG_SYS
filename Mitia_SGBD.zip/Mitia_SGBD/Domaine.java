package relation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Domaine implements Serializable {
    private List<Class<?>> typesAcceptes;

    // Constructeur
    public Domaine(List<Class<?>> typesAcceptes) {
        this.typesAcceptes = new ArrayList<>(typesAcceptes);
    }

    // Retourne le premier type accepté par le domaine
    public Class<?> getType() {
        if (typesAcceptes != null && !typesAcceptes.isEmpty()) {
            return typesAcceptes.get(0); // Premier type accepté
        }
        return null; // Aucun type défini
    }

    // Vérifie si le type est compatible avec le domaine
    public boolean isCompatible(Class<?> type) {
        return typesAcceptes.contains(type);
    }

    // Ajoute un type si ce n'est pas déjà présent
    public void ajouterType(Class<?> type) {
        if (!typesAcceptes.contains(type)) {
            typesAcceptes.add(type);
        }
    }

    // Ajoute plusieurs types
    public void ajouterTypes(List<Class<?>> types) {
        for (Class<?> type : types) {
            ajouterType(type);
        }
    }

    // Getter pour accéder à la liste des types acceptés
    public List<Class<?>> getTypesAcceptes() {
        return typesAcceptes;
    }

    // Affichage sous forme de chaîne
    @Override
    public String toString() {
        return "Domaine{" +
                "typesAcceptes=" + typesAcceptes +
                '}';
    }
}
