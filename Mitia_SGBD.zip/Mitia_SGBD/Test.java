package aff;

import java.util.ArrayList;
//import java.util.function.Predicate;
import operation.Operation;
import relation.*;

public class Test {

    public static void main(String[] args) {

        // Domaine qui accepte des types comme Class<?> (ex: String.class, Integer.class)
        ArrayList<Class<?>> typesString = new ArrayList<>();
        typesString.add(String.class);
        Domaine domaineString = new Domaine(typesString);

        ArrayList<Class<?>> typesInteger = new ArrayList<>();
        typesInteger.add(Integer.class);
        Domaine domaineInteger = new Domaine(typesInteger);

        ArrayList<Class<?>> typesBoolean = new ArrayList<>();
        typesBoolean.add(Boolean.class);
        Domaine domaineBoolean = new Domaine(typesBoolean);

        // Domaine mixte qui accepte String et Integer
        ArrayList<Class<?>> typesMixte = new ArrayList<>();
        typesMixte.add(String.class);
        typesMixte.add(Integer.class);
        Domaine domaineMixte = new Domaine(typesMixte);

        // Définition des colonnes
        ArrayList<Attribut> colonnes = new ArrayList<>();
        colonnes.add(new Attribut("Nom", domaineString));
        colonnes.add(new Attribut("Numero", domaineInteger));
        colonnes.add(new Attribut("Classe", domaineMixte));

        // Données des étudiants
        ArrayList<Nuplet> lignes = new ArrayList<>();

        ArrayList<Object> etudiant1 = new ArrayList<>();
        etudiant1.add("Alice");
        etudiant1.add(12345);
        etudiant1.add(1234);

        ArrayList<Object> etudiant2 = new ArrayList<>();
        etudiant2.add("Bob");
        etudiant2.add(67890);
        etudiant2.add("Physique");

        ArrayList<Object> etudiant3 = new ArrayList<>();
        etudiant3.add("Charlie");
        etudiant3.add(54321);
        etudiant3.add("Informatique");

        ArrayList<Object> etudiant4 = new ArrayList<>();
        etudiant4.add("David");
        etudiant4.add(98765);
        etudiant4.add("Mathématiques");

        lignes.add(new Nuplet(etudiant1));
        lignes.add(new Nuplet(etudiant2));
        lignes.add(new Nuplet(etudiant3));
        lignes.add(new Nuplet(etudiant4));

        // Création du tableau des étudiants
        Tableau tabStudent = new Tableau(colonnes, lignes, 3);
        System.out.println("Tableau des étudiants :");
        tabStudent.afficherTableau();

        System.out.println("\n");

        // Création de la projection
        ArrayList<Attribut> colonnesIlaina = new ArrayList<>();
        colonnesIlaina.add(new Attribut("Classe", domaineMixte));

        Operation op = new Operation();
        Tableau TabProjection = op.Projection(tabStudent, colonnesIlaina);
        System.out.println("Projection du tableau des étudiants (Class) :");
        TabProjection.afficherTableau();

        System.out.println("\n");

        // TABLEAU MATIERES
        ArrayList<Attribut> colonnesMatiere = new ArrayList<>();
        colonnesMatiere.add(new Attribut("Coefficient", domaineInteger));
        colonnesMatiere.add(new Attribut("Nom", domaineString));
        colonnesMatiere.add(new Attribut("Validite", domaineBoolean));

        ArrayList<Nuplet> lignesMatiere = new ArrayList<>();

        ArrayList<Object> matiere1 = new ArrayList<>();
        matiere1.add(5);
        matiere1.add("Mathématiques");
        matiere1.add(true);

        ArrayList<Object> matiere2 = new ArrayList<>();
        matiere2.add(4); 
        matiere2.add("Physique");
        matiere2.add(false);

        ArrayList<Object> matiere3 = new ArrayList<>();
        matiere3.add(3);
        matiere3.add("Informatique");
        matiere3.add(true);

        lignesMatiere.add(new Nuplet(matiere1));
        lignesMatiere.add(new Nuplet(matiere2));
        lignesMatiere.add(new Nuplet(matiere3));

        // Création du tableau des matières
        Tableau tabMatiere = new Tableau(colonnesMatiere, lignesMatiere, 3);
        System.out.println("Tableau des matières :");
        tabMatiere.afficherTableau();

        System.out.println("\n");

        // TEST PRODUIT CARTESIEN
        Tableau produitCartesien = op.ProduitCartesien(tabStudent, tabMatiere);
        System.out.println("Produit cartésien des tableaux Étudiants et Matières :");
        produitCartesien.afficherTableau();

        System.out.println("\n");
        // TEST SELECTION
        // Sélectionner les étudiants avec le nom égal à "Alice"
Tableau tabSelection1 = op.selection("Numero", "=", "67890" , tabStudent);
System.out.println("Sélection des étudiants avec le nom 'Alice' :");
tabSelection1.afficherTableau();

 

Tableau tabSelection5 = op.selection("Nom", "=", "Bob", tabStudent);
System.out.println("Sélection des étudiants dont le nom n'est pas 'Bob' :");
tabSelection5.afficherTableau();


// Sélectionner les étudiants avec un numéro plus grand que 50000
/*Tableau tabSelection2 = op.selection("Numero", ">", 50000, tabStudent);
System.out.println("Sélection des étudiants avec un numéro > 50000 :");
tabSelection2.afficherTableau();

// Sélectionner les étudiants dont le nom commence par "A"
Tableau tabSelection3 = op.selection("Nom", "LIKE_START", "A%", tabStudent);
System.out.println("Sélection des étudiants dont le nom commence par 'A' :");
tabSelection3.afficherTableau();

// Sélectionner les étudiants dont le nom contient "li"
Tableau tabSelection4 = op.selection("Nom", "LIKE", "%li%", tabStudent);
System.out.println("Sélection des étudiants dont le nom contient 'li' :");
tabSelection4.afficherTableau();

// Sélectionner les étudiants dont le nom est différent de "Bob"
*/

    }
}
